# OnePageLove Chess

**1,000 free, standalone chess lessons. One subject. One HTML page.**

This repository is designed for GitHub Pages and for offline use. Every lesson under `lessons/` is a completely self-contained HTML file with its own CSS and no external dependencies.

## What is included

- **1,000 lessons**
- **20 training divisions**
- Opening foundations
- White opening repertoires
- Black defenses
- Pawn structures
- Strategy and piece play
- Attacking and defense
- Tactical motifs
- Calculation
- Pawn, rook, minor-piece, queen and mixed endgames
- Practical tournament chess
- Study and improvement
- Chess mathematics, rules and history

Each of the 200 base subjects has five independent lessons:

1. Complete Guide
2. Recognition Guide
3. Decision Rules
4. Mistakes and Counterplay
5. Training and Self-Test

## Philosophy

The goal is not to manufacture pages. Each page should teach a reusable chess idea and stand on its own so a learner can arrive from a search engine or GitHub Pages without reading anything else first.

AI can create excellent educational material when it is asked to explain, organize, test and drill ideas rather than merely produce text. These pages are intended as a free resource for anyone who wants to learn.

## GitHub Pages

The package includes:

- `index.html` — searchable homepage
- `.nojekyll`
- `404.html`
- `SITEMAP.html`
- `sitemap.xml`
- `categories/`
- `lessons/`
- `tools/verify_site.py`

To publish, push the files to your repository and configure GitHub Pages to deploy from `main` and `/(root)`.

## Accuracy

AI is powerful, but not infallible. Chess is concrete. Verify critical forcing opening lines and current competition rules with authoritative sources before serious tournament use.

Rules/history references:
- FIDE Laws of Chess: https://handbook.fide.com/chapter/E012023
- Claude Shannon, *Programming a Computer for Playing Chess* (1950): https://vision.unipv.it/IA1/ProgrammingaComputerforPlayingChess.pdf

## Use

**AI-made by ChatGPT for the OnePageLove chess-learning project. Free educational material; not intended for resale. Chess itself is a centuries-old game, while these pages are original AI-generated instructional material.**
