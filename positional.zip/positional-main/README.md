# Positional Logic

A dependency-free, GitHub Pages-ready course with **500 standalone chess lessons** plus a searchable course homepage.

## Publish on GitHub Pages

1. Create a GitHub repository (the name `positional-logic` is recommended).
2. Upload everything in this folder to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, then select **main** and **/(root)**.
5. Save. GitHub will show the public URL after deployment.

No build step, framework, server, or external asset is required. Open `index.html` locally to use the course offline. Lesson completion is stored only in the visitor's browser.

## Course design

The curriculum revisits 50 durable positional patterns over ten passes: Notice, Evaluate, Plan, Improve, Prevent, Exchange, Candidates, Calculate, Play both sides, and Master. This spiral structure makes abstract logic concrete without demanding long study sessions.

## Maintenance

- Rebuild all pages: `node tools/generate-site.mjs`
- Validate the site: `node tools/validate-site.mjs`

The checked-in HTML is the deployable site; the scripts are included only to make future edits reproducible.
